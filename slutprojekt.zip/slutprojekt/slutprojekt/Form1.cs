﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slutprojekt
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + " / ";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + " x ";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + " - ";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + " + ";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "√ ";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3,14";         //Pi = 3,14
        }

        private void button19_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ",";            //Viktigt att använda , och inte . eftersom att det är det talsystemet som anvädns
        }
        private void button16_Click(object sender, EventArgs e)
        {
            string[] nummer = textBox1.Text.Split(' ');     //En array som heter nummer, den får värden som står i textBox1. Uppdelade vid mellanrum, alltså vid operatorer
            if (nummer.Length <= 3)
            {
                if (nummer[1] == "+")
                {
                    double tal1 = double.Parse(nummer[0]);      //Parsea string:arna till doubles
                    double tal2 = double.Parse(nummer[2]);
                    double svar = tal1 + tal2;                  //Utför operation
                    textBox1.Text = Convert.ToString(svar);     //Skriver ut svaret efter att det är convertat till string
                    nummer[0] = Convert.ToString(svar);         //Ändrar det första talet till svaret
                }
                else if (nummer[1] == "-")
                {
                    double tal1 = double.Parse(nummer[0]);
                    double tal2 = double.Parse(nummer[2]);
                    double svar = tal1 - tal2;
                    textBox1.Text = Convert.ToString(svar);
                    nummer[0] = Convert.ToString(svar);
                }
                else if (nummer[1] == "/")
                {
                    double tal1 = double.Parse(nummer[0]);
                    double tal2 = double.Parse(nummer[2]);
                    double svar = tal1 / tal2;
                    textBox1.Text = Convert.ToString(svar);
                    nummer[0] = Convert.ToString(svar);
                }
                else if (nummer[1] == "x")
                {
                    double tal1 = double.Parse(nummer[0]);
                    double tal2 = double.Parse(nummer[2]);
                    double svar = tal1 * tal2;
                    textBox1.Text = Convert.ToString(svar);
                    nummer[0] = Convert.ToString(svar);
                }
                else if (nummer[0] == "√")
                {
                    double tal1 = double.Parse(nummer[1]);  //tal1 blir det andra nummret man skriver, alltså det efter roten ur tecknet.
                    double tal2 = Math.Sqrt(tal1);          //Tar kvadrat roten av tal1 och anger det till tal2 som skrivs ut
                    textBox1.Text = Convert.ToString(tal2);
                }
            }
            else if(nummer.Length > 3)      //Om arrayen nummer är längre än 3 alltså att det finns mer än en operator skickas en messagebox med error, och textrutan tömms
            {
                textBox1.Text = "";
                MessageBox.Show("Endast en operation i taget! Tryck = först!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
     }
}
